import React from 'react';

import Accordion from './Components/Accordion/Accordion';

const App = () => {
  return (
    <div >
      <Accordion />
    </div>
  );
};

export default App;

